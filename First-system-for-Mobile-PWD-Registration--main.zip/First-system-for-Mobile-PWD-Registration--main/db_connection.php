<?php
// db_connection.php
// Centralized DB connection - include this in other scripts

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = ''; // set your password
$DB_NAME = 'pwd_verification';

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

// handle connection error
if ($conn->connect_error) {
    // In production, log error
    error_log("Database connection failed: " . $conn->connect_error);
    // Show generic message to user
    die("Database unavailable. Please try again later.");
}
$conn->set_charset('utf8mb4');
?>