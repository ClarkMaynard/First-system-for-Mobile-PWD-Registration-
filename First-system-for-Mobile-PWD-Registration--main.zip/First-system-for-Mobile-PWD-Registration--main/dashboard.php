<?php
// dashboard.php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.html");
    exit;
}
include 'db_connection.php';

$PWD_ID = $_SESSION['PWD_ID'];
$stmt = $conn->prepare("
    SELECT FullName, DateOfBirth, Gender, DisabilityType, QR_Path, ID_Image 
    FROM PWD_User WHERE PWD_ID = ?
");
$stmt->bind_param("i", $PWD_ID);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>PWD Dashboard</title>
  <link rel="stylesheet" href="style.css">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    body { margin:0; font-family:Calibri; }
    .layout { display:flex; height:100vh; }
    .sidebar { width:220px; background:#222; color:white; padding:20px; }
    .sidebar a { color:white; text-decoration:none; display:block; margin:10px 0; }
    .sidebar a:hover { color:#ffd700; }
    .main { flex:1; padding:20px; overflow:auto; }
    .card { background:white; padding:20px; border-radius:10px; box-shadow:0 0 5px #aaa; }
  </style>
</head>
<body>
<div class="layout">
  <div class="sidebar">
    <h2>PWD Portal</h2>
    <a href="dashboard.php">Home</a>
    <a href="about.html">About</a>
    <a href="verify.html">Verify</a>
    <a href="deals.html">Deals</a>
    <a href="settings.html">Settings</a>
    <hr>
    <a href="logout.php" style="color:#ffcccc;">Logout</a>
  </div>
  <div class="main">
    <h1>Welcome, <?php echo htmlspecialchars($user['FullName']); ?>!</h1>
    <div class="card">
      <p><b>Date of Birth:</b> <?php echo htmlspecialchars($user['DateOfBirth']); ?></p>
      <p><b>Gender:</b> <?php echo htmlspecialchars($user['Gender']); ?></p>
      <p><b>Disability Type:</b> <?php echo htmlspecialchars($user['DisabilityType']); ?></p>
      <?php if ($user['QR_Path']): ?>
        <p><b>Your Verification QR:</b><br>
          <img src="<?php echo htmlspecialchars($user['QR_Path']); ?>" width="150">
        </p>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
if (sessionStorage.getItem('justLoggedIn') === 'true') {
  alert('Welcome! Your profile has been successfully loaded.');
  sessionStorage.removeItem('justLoggedIn');
}
</script>
</body>
</html>
