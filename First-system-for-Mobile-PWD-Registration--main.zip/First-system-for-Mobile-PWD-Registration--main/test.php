<?php
$conn = new mysqli("localhost", "root", "", "pwd_verification_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully!";
?>
